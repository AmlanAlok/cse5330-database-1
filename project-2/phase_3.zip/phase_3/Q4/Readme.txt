
Team Members:
Amlan Alok
Aniket Yamle


We have used the command line interface to interact with the user to implement Q4.

Please go to Q4 directory in terminal and run the below command to start the program.

python3 user_interaction.py

5 options will be displayed and you can choose your action.

Screenshots have been provided from when we tested our code.
