
delete from state where state = 'Wyoming';