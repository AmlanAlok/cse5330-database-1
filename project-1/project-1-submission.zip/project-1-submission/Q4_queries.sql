
insert into state values (51,"Wyoming","DD",1890,"Cheyenne",1869,21.1,1,59466,91738);

insert into county values (null,"Autauga",55869,32.53952745,-86.64408227);

insert into state values (51,"Wyoming","DD","text","Cheyenne",1869,21.1,1,59466,91738);


