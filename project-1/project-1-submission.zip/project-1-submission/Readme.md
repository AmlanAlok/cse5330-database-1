
Command to run Q2 data insertion python script is below:

python3 Q2_insert_data.py



All queries and output files have been included in the zip


Q3_output_1_2_3_limited.txt contains the output of 2 and 3 displaying only 1000 records as a shorter version.
Q3_output_1_2_3.txt contains 12 lakh records for 2 and 3 each
