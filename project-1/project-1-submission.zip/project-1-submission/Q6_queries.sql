
insert into state values (51,"Wyoming-A","DD",1890,"Cheyenne",1869,21,1,59466,91738);
insert into state values (52,"Wyoming-B","DD",1890,"Cheyenne",1869,21,1,59466,91738);
insert into state values (53,"Wyoming-C","DD",1890,"Cheyenne",1869,21,1,59466,91738);